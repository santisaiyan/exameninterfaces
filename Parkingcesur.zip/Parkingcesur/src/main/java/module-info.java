module com.example.parkingcesur {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.parkingcesur to javafx.fxml;
    exports com.example.parkingcesur;
}