import java.util.Date;

public class Coche {
    private String matricula;
    private String modelo;
    private String cliente;
    private String tipoTarifa;
    private Date fechaEntrada;
    private Date fechaSalida;
    private double costeTotal;

    // Constructor
    public Coche(String matricula, String modelo, String cliente, String tipoTarifa, Date fechaEntrada, Date fechaSalida) {
        this.matricula = matricula;
        this.modelo = modelo;
        this.cliente = cliente;
        this.tipoTarifa = tipoTarifa;
        this.fechaEntrada = fechaEntrada;
        this.fechaSalida = fechaSalida;
        calcularCosteTotal();
    }

    // Getters y Setters (omitidos para brevedad)

    // Método para calcular el costo total según las fechas de entrada y salida y el tipo de tarifa
    private void calcularCosteTotal() {
        long diferenciaEnMilisegundos = fechaSalida.getTime() - fechaEntrada.getTime();
        long diferenciaEnDias = diferenciaEnMilisegundos / (1000 * 60 * 60 * 24);

        double precioDiario = obtenerPrecioDiario(tipoTarifa);
        costeTotal = diferenciaEnDias * precioDiario;
    }

    // Método para obtener el precio diario según el tipo de tarifa
    private double obtenerPrecioDiario(String tipoTarifa) {
        double precioDiario = 0;
        switch (tipoTarifa) {
            case "Standard":
                precioDiario = 8;
                break;
            case "Oferta":
                precioDiario = 6;
                break;
            case "Larga duración":
                precioDiario = 2;
                break;
            default:
                System.out.println("Tipo de tarifa no válido");
                break;
        }
        return precioDiario;
    }
}
